<?php 
/** 
**Include vmagazine widgets
**/

require get_stylesheet_directory() . '/inc/widgets/vmagazine-news-post-column.php'; // Grid/List

 ?>