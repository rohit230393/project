<?php
/**
 * Vmagazine News functions and definitions
 *
 * @package Vmagazine News 
 */
 
function vmagazine_news_enqueue_styles() {

    wp_enqueue_style( 'vmag_news-parent-style', get_template_directory_uri() . '/style.css' );

    wp_enqueue_style( 'vmagazine-responsive', get_stylesheet_directory_uri(). '/assets/css/child-responsive.css',array('elegant-fonts','vmagazine-lite-responsive'), VMAG_VER );

    $vmagazine_news_font_args = array(
            'family' => 'Roboto:300,400,500,700,900');
    wp_enqueue_style( 'vmagazine-news-google-fonts', add_query_arg( $vmagazine_news_font_args, "//fonts.googleapis.com/css" ) );

}
add_action( 'wp_enqueue_scripts', 'vmagazine_news_enqueue_styles' );

/**
 * Extra Init.
 */
require get_stylesheet_directory() . '/inc/init.php';



if ( ! function_exists( 'vmagazine_lite_credit' ) ) {
    /**
     * Display the theme credit/button footer
     * @since  1.0.0
     * @return void
     */
    function vmagazine_lite_credit() {
        ?>
                <div class="site-info">
                    <?php $copyright = get_theme_mod( 'vmagazine_lite_copyright_text' ); 
                    if( !empty( $copyright ) ) { 
                        echo wp_kses_post($copyright) . " | "; 
                    } ?>
                    <?php echo esc_html__('WordPress Theme :', 'vmagazine-news'); ?> <a href="https://accesspressthemes.com/" target="_blank">VMagazine News</a> 
                </div><!-- .site-info -->               
        <?php
    }
}