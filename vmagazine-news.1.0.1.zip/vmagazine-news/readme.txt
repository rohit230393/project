=== Zigcy Lite ===

Contributors: access-keys
Tags: right-sidebar, left-sidebar, custom-menu, featured-images, threaded-comments, translation-ready, custom-logo, custom-colors, blog, post-formats, custom-header, editor-style, news, e-commerce
Requires at least: 4.5
Tested up to: 5.1
Requires PHP: 5.6
Stable tag: 1.0.1
License: GNU General Public License, version 3 (GPLv3)
License URI: http://www.gnu.org/licenses/gpl-3.0.txt


== Description ==

Vmagazine News is a child theme for Vmagazine Lite, suitable for creating any types of newspaper, magazine, and blog websites. It uses SiteOrigin Page Builder plugin for creating flexible pages with different areas for advertisements and widgets. The theme comes with 9 inbuilt widgets with powerful configuration features for making your website more engaging and appealing. Moreover, the template also contains a news ticker to highlight your hot/breaking news and a live AJAX search bar to make searching of your web contents easier and faster for your users.



Vmagazine News WordPress Theme, Copyright 2019 AccessPress Themes
Vmagazine News is distributed under the terms of the GNU GPL



== Changelog ==

= 1.0.1  - March 15 2019 =
* Minor issue fixed
* Minor CSS changed

= 1.0.0  - March 12 2019 =
* Initial release

* Implement Smart Slider Plugin and added it in Slider Section

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Vmagazine News includes support for Infinite Scroll in Jetpack.



== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)

== Screenshot Images ==

Stocksnap Images
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/license

Alexander Voigt
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/photo/VWUE0OMOGS

Elliott Chau
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/photo/SPYOGV0DTL

The Lazy Artist Gallery
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/photo/ZNZZGFVY89

Toa Heftiba
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/photo/FG3EB2F64Q

Josh Wilburne
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/photo/YJELJPJLOO

Bruce Mars
License: CC0 1.0 Universal (CC0 1.0)
Source: https://stocksnap.io/photo/NJVNNNG7TM